# Budżet Domowy App

Prototyp webowej aplikacji do zarządzania budżetem domowym:
- Dochody, wydatki z kategoriami, oszczędności
- Wykorzystuje localStorage do zapisu danych
- Tryb ciemny automatyczny

## Użycie

1. Otwórz `index.html` w przeglądarce.
2. Dodaj do ekranu głównego na iOS (Safari > Udostępnij > Dodaj do ekranu początkowego).
3. Korzystaj offline, dane są zapisywane lokalnie.

## Publikacja na GitHub Pages

1. Zmień nazwę pliku `index.html` w repozytorium GitHub.
2. Włącz GitHub Pages w ustawieniach (branch `main`, folder `/`).
3. Aplikacja będzie dostępna pod `https://<username>.github.io/budzet-app/`.
